# 훈민（훈민）APKをスマホだけで作る手順

## このZIPについて
Android Studioをスマホにインストールせず、GitHub ActionsのクラウドでAPKをビルドするための設定 `.github/workflows/build-apk.yml` を追加しています。

## 重要
この方法では、GitHubにプロジェクトのファイルをリポジトリとして置く必要があります。ZIPをGitHubにアップロードしただけでは、ZIP内のファイルが展開されず、ビルドは動きません。

## スマホだけで進める流れ
1. GitHubアカウントを用意し、新しい**Private repository（非公開リポジトリ）**を作ります。
2. ZIPを端末にダウンロードして展開します。
3. 展開したプロジェクトの中身（`settings.gradle`、`build.gradle`、`app`、`.github` など）を、フォルダ構成を保ってリポジトリにアップロードします。GitHubのスマホ画面でフォルダ構成を保った一括アップロードが難しい場合、この手順はスマホだけでは扱いにくいことがあります。
4. リポジトリの **Actions** タブを開き、`Build 훈민 APK` を選択して **Run workflow** を押します。初回はワークフローの有効化が必要な場合があります。
5. 完了した実行を開き、**Artifacts** の `hunmin-debug-apk` をダウンロードします。
6. ZIP形式のArtifactを展開し、中の `app-debug.apk` をタップしてインストールします。Androidが確認を求めた場合は、内容と提供元を確認してから許可してください。

## ビルド設定
- Java 17
- Gradle 8.9
- Android SDK platform 35
- 出力：`app/build/outputs/apk/debug/app-debug.apk`

## データについて
アプリ内の辞書JSONはassetsに同梱されます。更新JSONはインストール済みアプリ内から選んで取り込みます。基本機能はオフライン動作を想定しています。

## トラブル時
Actionsの実行が赤い×になった場合、実行ページの最初の赤いエラー部分を確認します。GitHubのパスワード、認証コード、アクセストークンなどは、チャットや公開リポジトリに貼らないでください。

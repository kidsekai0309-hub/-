# 훈민 Android アプリ化プロジェクト

## 実装方針
既存のHTMLをWebView内で動かし、辞書画面・検索・日本語/한국어切替・ブックマーク・例文集・設定・データ管理を維持します。

## JSON自動読み込みとオフライン動作
- 起動時にアプリ内蔵の `app/src/main/assets/hunmin_data.json` をAndroidブリッジ経由で自動読み込みします。ネット接続や `fetch()` のfile URL制限に依存しません。
- 内蔵JSONにはHTMLの初期データ全22単語・2例文を格納しています。
- 取り込んだJSONは端末内の自動バックアップに保存され、次回起動時に内蔵JSONより優先して復元されます。
- 「データ管理 → バックアップを読み込む」からAndroidのファイル選択画面でJSONを選択できます。取り込み前にJSON形式と単語件数を検証し、失敗時は既存データを保持します。
- 「バックアップを書き出す」はAndroidの保存先選択画面を使います。
- アプリはインターネット権限を要求せず、基本機能はオフラインで動作します。

## ビルドについて
この作業環境ではAndroid SDK / Android Gradle Pluginのビルド環境が確認できなかったため、APKそのものはまだ生成・実機テストできていません。これはAndroid Studioでビルドするためのプロジェクト一式です。

1. Android Studioでこのプロジェクトフォルダを開きます。
2. Gradle Syncを完了します。
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)` を選択します。
4. APKは通常 `app/build/outputs/apk/debug/app-debug.apk` に出力されます。

## JSONデータの更新
インストール後はアプリ内の「メニュー → データ管理 → バックアップを読み込む」でJSONを選択します。受け付ける形式は `{"words":[...],"examples":[...]}` または훈민のバックアップ形式（`{"data":{"words":[...],"examples":[...]}, ...}`）です。起動時の内蔵JSON自体を更新する場合のみ、assetsのJSONを差し替えて再ビルドします。

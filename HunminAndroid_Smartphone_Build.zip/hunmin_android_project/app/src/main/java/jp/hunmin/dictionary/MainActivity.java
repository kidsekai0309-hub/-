package jp.hunmin.dictionary;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_IMPORT_JSON = 4101;
    private static final int REQUEST_EXPORT_JSON = 4102;
    private WebView webView;
    private String pendingExportJson;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.addJavascriptInterface(new HunminBridge(), "HunminAndroid");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/hunmin_autobackup.html");
    }

    private class HunminBridge {
        @JavascriptInterface public String getBundledJson() {
            try (InputStream in = getAssets().open("hunmin_data.json"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096]; int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                return out.toString("UTF-8");
            } catch (Exception e) { return "{\"version\":2,\"words\":[],\"examples\":[]}"; }
        }
        @JavascriptInterface public void pickJson() { runOnUiThread(() -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "application/octet-stream"});
            startActivityForResult(intent, REQUEST_IMPORT_JSON);
        }); }
        @JavascriptInterface public void saveJson(String json, String filename) { runOnUiThread(() -> {
            pendingExportJson = json; Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, filename == null ? "hunmin_backup.json" : filename);
            startActivityForResult(intent, REQUEST_EXPORT_JSON);
        }); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQUEST_IMPORT_JSON) {
            try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                if (in == null) throw new IllegalStateException("Cannot open JSON");
                byte[] buffer = new byte[4096]; int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                String json = out.toString("UTF-8");
                String quoted = JSONObject.quote(json);
                webView.evaluateJavascript("window.hunminImportJson && window.hunminImportJson(" + quoted + ")", null);
            } catch (Exception e) { Toast.makeText(this, "JSONを読み込めませんでした。", Toast.LENGTH_LONG).show(); }
        } else if (requestCode == REQUEST_EXPORT_JSON) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null || pendingExportJson == null) throw new IllegalStateException("Cannot save backup");
                out.write(pendingExportJson.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "훈민バックアップを保存しました。", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "バックアップ保存に失敗しました。", Toast.LENGTH_LONG).show(); }
            finally { pendingExportJson = null; }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("(function(){if(document.getElementById('menuPanel')?.classList.contains('open')){document.getElementById('menuPanel').classList.remove('open');return 'handled';}if(window.history.length>1){history.back();return 'handled';}return 'exit';})()", value -> { if (value == null || value.contains("exit")) finish(); });
        else super.onBackPressed();
    }
    @Override protected void onDestroy() { if (webView != null) webView.destroy(); super.onDestroy(); }
}
